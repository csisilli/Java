package com.example.spinnerproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<String> {
    Context mainContext;
    List<String> list;
    int layout;
    LayoutInflater inflater;
    Button button;

    ImageView imageView;
    public CustomAdapter(@NonNull Context context, int resouce, int textViewResourceId, @NonNull List<String> objects) {
       super(context,resouce,textViewResourceId, objects);
        mainContext = context;
        list=objects;
        layout= resouce;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }
    @NonNull

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View v=inflater.inflate(R.layout.adapter,null);
        ImageView imageView = v.findViewById(R.id.id_image);
        TextView textView= v.findViewById(R.id.id_text);
        Button button =v.findViewById(R.id.id_button);
        switch(position){
            case 0:
                if(position ==0){
                    imageView.setImageResource(R.drawable.dog);
                }
                break;
            case 1:
                if(position ==1){
                    imageView.setImageResource(R.drawable.cat);
                }
                break;
            case 2:
                if(position ==2){
                    imageView.setImageResource(R.drawable.doge);
                }
                break;
            case 3:
                if(position ==3){
                    imageView.setImageResource(R.drawable.pop);
                }
                break;
            default:
                imageView.setImageResource(R.drawable.dog);
                break;
        }
        textView.setText(list.get(position));
        return v;
    }

    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View v=inflater.inflate(R.layout.adapter,null);
        ImageView imageView = v.findViewById(R.id.id_image);
        TextView textView= v.findViewById(R.id.id_text);
        switch(position){
            case 0:
                if(position ==0){
                    imageView.setImageResource(R.drawable.dog);
                }
                break;
            case 1:
                if(position ==1){
                    imageView.setImageResource(R.drawable.cat);
                }
                break;
            case 2:
                if(position ==2){
                    imageView.setImageResource(R.drawable.doge);
                }
                break;
            case 3:
                if(position ==3){
                    imageView.setImageResource(R.drawable.pop);
                }
                break;
            default:
                imageView.setImageResource(R.drawable.dog);
                break;
        }
        textView.setText(list.get(position));
        return v;
    }


    public void insert(@Nullable String object, int index,int position) {
        super.insert(object, index);
        View v=inflater.inflate(R.layout.adapter,null);
        TextView textView=(TextView)v.findViewById(R.id.id_text);
        Button button =v.findViewById(R.id.id_button);
        switch(position){
            case 0:
                if(position ==0){
                    button.callOnClick();

                    textView.setText(list.get(position));
                }
                break;
            case 1:
                if(position ==1){
                    button.callOnClick();
                    textView.setText(list.get(position));
                }
                break;
            case 2:
                if(position ==2){
                    button.callOnClick();
                    textView.setText(list.get(position));
                }
                break;
            case 3:
                if(position ==3){
                    button.callOnClick();
                    textView.setText(list.get(position));
                }
                break;
            default:
                button.callOnClick();
                textView.setText(list.get(position));
                break;
        }

    }
}

