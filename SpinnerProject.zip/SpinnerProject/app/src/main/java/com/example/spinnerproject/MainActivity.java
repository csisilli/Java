package com.example.spinnerproject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static String store="";
    TextView textView;
    Button button;
    Spinner spinner;
    ArrayList<String>list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.id_spinner);
        button = findViewById(R.id.id_button);
        textView= findViewById(R.id.id_textview);
        list = new ArrayList<>();
        list.add("Dog");
        list.add("Cat");
        list.add("Doge");
        list.add("Pop Cat");
        CustomAdapter adapter = new CustomAdapter(this, R.layout.adapter, R.id.id_text, list);
        spinner.setAdapter(adapter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String item =spinner.getSelectedItem().toString();
               store+=item+", ";
                textView.setText(store);

            }
        });
        }


    }
