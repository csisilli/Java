package com.example.myapplication;

import android.widget.RadioButton;

public class Question {
    private int answer;
    private int correctanswer;

    public Question(int answer,int correctanswer){
        this.answer = answer;
        this.correctanswer = correctanswer;
    }



    // return answer
    public int getAnswer()
    {
        return answer;
    }
    public void setAnswer(int answer)
    {
        this.answer= answer;
    }
    // return the correct answer
    public int isAnswerCorrect()
    {
        return correctanswer;
    }
    //the right answers
    public void setCorrectanswer(int correctanswer)
    {
        this.correctanswer = correctanswer;
    }
}
