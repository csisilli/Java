package com.example.myapplication;

import static com.example.myapplication.R.drawable.*;

import androidx.appcompat.app.AppCompatActivity;

//import android.content.Intent;
import android.os.Bundle;
//import android.view.View;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  {
    Button next;
    RadioButton question1;
    RadioButton question2;
    RadioButton question3;
    RadioButton question4;
    TextView text;
    ImageView image;
    //ArrayList<Quiz> Quizes;
    int counter;
    private int correct=0;
    private int currentamount=0;
    private Question[] answers=new Question[]{
            //new Question(R.string.a,"A"),


    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setting up the button and radio buttons
        next = findViewById(R.id.button);
        question1 = findViewById(R.id.radioButton);
        question2 = findViewById(R.id.radioButton2);
        question3 = findViewById(R.id.radioButton3);
        question4 = findViewById(R.id.radioButton4);
        text = findViewById(R.id.textView);
        image = findViewById(R.id.photo);
        image.setImageResource(oop);
        //Quiz = new ArrayList<>();
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view){
                   counter=counter+1;
                  if(counter==1){
                      text.setText("What letter is the top right one?");
                      image.setImageResource(photo);
                      if(question3.isChecked()){
                          correct=currentamount+1;
                      }

                   }
                  if(counter==2){
                      text.setText("Which person is Kim Kardashian?");
                      image.setImageResource(celeb);
                      if(question2.isChecked()){
                         correct =currentamount+2;
                      }
                  }
                  if(counter==3) {
                      text.setText("Which animal is a wolf?");
                      image.setImageResource(anim);
                      if(question4.isChecked()){
                          currentamount=currentamount+3;
                      }
                  }
                  if(counter ==4){
                      text.setText("Which cat is orange?");
                      image.setImageResource(cats);
                      if(question1.isChecked()){
                          correct=currentamount+4;
                      }
                  }
                  if(counter ==5){
                      text.setText("Which console is the PC?");
                      image.setImageResource(conso);
                      if(question4.isChecked()){
                          correct=currentamount+5;
                      }
                  }
                  if(counter ==6){
                      text.setText("Which pokemon is Pikachu?");
                      image.setImageResource(poke);
                      if(question4.isChecked()){
                          correct=currentamount+6;
                      }
                  }
                      if(counter ==7){
                          text.setText("You Finished the Quiz! You got  "+ correct + "out of 6");
                          image.setImageResource(woo);
                      }
                  }

            });
    }


}