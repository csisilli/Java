package com.example.assignment3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    public int total = 0;
    public int red;
    public int blue;
    public int yellow;
    RadioGroup radioGroupred;
    RadioGroup radiogroupblue;
    RadioGroup radiogroupyel;
    Button resetButton;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.id_total);
        radioGroupred = findViewById(R.id.id_radio_group);
        resetButton= findViewById(R.id.id_resetbutton);

        //the reset button
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.setText("Total");
                textView.dispatchDisplayHint(View.VISIBLE);

                resetButton.setText("Reset");
            }
        });
        // a switch case statement where if user clicks button the button number is clicked
        radioGroupred.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.id_red_9:
                        red =  900;
                        break;
                    case R.id.id_red_8:
                        red =  800;
                        break;
                    case R.id.id_red_7:
                        red  =  700;
                        break;
                    case R.id.id_red_6:
                        red = 600;
                        break;
                    case R.id.id_red_5:
                        red = 500;
                        break;
                    case R.id.id_red_4:
                        red =  400;
                        break;
                    case R.id.id_red_3:
                        red  =  300;
                        break;
                    case R.id.id_red_2:
                        red= 200;
                        break;
                    case R.id.id_red_1:
                        red= 100;
                        break;
                    case R.id.id_red_0:
                        red= 0;
                        break;
                }
                // the total shows on the textview
                total=red+blue+yellow;
                TextView text=(TextView)findViewById(R.id.id_total);
                text.setText("Total: "+total);

            }
        });
        radiogroupblue =findViewById(R.id.id_radio_group1);
        radiogroupblue.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.id_blue_9:
                        blue = 90;
                        break;
                    case R.id.id_blue_8:
                        blue= 80;
                        break;
                    case R.id.id_blue_7:
                        blue= 70;
                        break;
                    case R.id.id_blue_6:
                        blue= 60;
                        break;
                    case R.id.id_blue_5:
                       blue= 50;
                        break;
                    case R.id.id_blue_4:
                        blue= 40;
                        break;
                    case R.id.id_blue_3:
                        blue =30;
                        break;
                    case R.id.id_blue_2:
                        blue= 20;
                        break;
                    case R.id.id_blue_1:
                        blue= 10;
                        break;
                    case R.id.id_blue_0:
                       blue= 0;
                        break;
                }
                total=red+blue+yellow;
                TextView text=(TextView)findViewById(R.id.id_total);
                text.setText("Total: "+total);
            }
        });
        radiogroupyel =findViewById(R.id.id_radio_group2);
        radiogroupyel.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.id_yellow_9:
                        yellow= 9;
                        break;
                    case R.id.id_yellow_8:
                        yellow= 8;
                        break;
                    case R.id.id_yellow_7:
                        yellow= 7;
                        break;
                    case R.id.id_yellow_6:
                        yellow= 6;
                        break;
                    case R.id.id_yellow_5:
                        yellow= 5;
                        break;
                    case R.id.id_yellow_4:
                        yellow= 4;
                        break;
                    case R.id.id_yellow_3:
                        yellow= 3;
                        break;
                    case R.id.id_yellow_2:
                        yellow= 2;
                        break;
                    case R.id.id_yellow_1:
                        yellow=1;
                        break;
                    case R.id.id_yellow_0:
                         yellow= 0;
                        break;
                }
                total=red+blue+yellow;
                TextView text=(TextView)findViewById(R.id.id_total);
                text.setText("Total: "+total);
            }

        });
       // resetButton = findViewById(R.id.id_resetbutton);









    }
}